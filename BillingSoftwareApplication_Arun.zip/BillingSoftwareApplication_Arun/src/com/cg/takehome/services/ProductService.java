package com.cg.takehome.services;

import com.capgemini.takehome.Exceptions.InValidQuantityException;
import com.capgemini.takehome.Exceptions.InvalidProductCodeException;
import com.capgemini.takehome.Exceptions.ProductCodeNotFoundException;
import com.capgemini.takehome.bean.Product;
import com.capgemini.takehome.dao.IProductDAO;
import com.capgemini.takehome.dao.ProductDAO;
import com.capgemini.takehome.util.CollectionUtil;

public class ProductService implements IProductService{
	
	IProductDAO dao= new ProductDAO();
	
	

	@Override
	public Product getProductDetails(int productCode) throws ProductCodeNotFoundException{
		
		if(dao.getProductDetails(productCode)==null)
		{
			throw new ProductCodeNotFoundException("this product code is not available");
		}
			return dao.getProductDetails(productCode);
			
			
	}

	@Override
	public boolean validateProductCode(int productCode) {
		
		if(dao.getProductDetails(productCode)==null)
		{
			throw new ProductCodeNotFoundException("the product code is not available");
		}
		String str=String.valueOf(productCode);
		if(str.length()>0&&str.length()<5)
			return true;
		else {
			
			throw new InvalidProductCodeException("The product Code<< "+productCode+">> is not available.");
		}
	
		
	}

	@Override
	public boolean validateProductQuantity(int quantity) {
	if(quantity>0)
		return true;
	else 
		throw new InValidQuantityException("quantity entered is invalid");
	}


	}

	
		
	
	
	

	


