package com.cg.takehome.services;


import com.capgemini.takehome.bean.Product;
import com.capgemini.takehome.dao.IProductDAO;
import com.capgemini.takehome.dao.ProductDAO;

public interface IProductService {
	IProductDAO dao=new ProductDAO();
	//abstract declaration of methods
	public Product getProductDetails(int productCode) ;
	
	
	public boolean validateProductQuantity(int quantity);
	boolean validateProductCode(int productCode);
	
	
		
	
}