package com.capgemini.takehome.dao;

import com.capgemini.takehome.bean.Product;
// this class is used for obtaining the data from collections.util
import com.capgemini.takehome.util.CollectionUtil;

public class ProductDAO implements IProductDAO{

	Product product;
	@Override
	public Product getProductDetails(int productCode) {
		
	
		return CollectionUtil.products.get(productCode);
		
	}

}
