package com.capgemini.takehome.dao;
//this the interface and implemented by ProductDAO
import com.capgemini.takehome.bean.Product;

public interface IProductDAO {
	Product getProductDetails(int productCode);

}
