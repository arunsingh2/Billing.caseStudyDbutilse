package com.capgemini.takehome.servicetesting;

import static org.junit.Assert.*;

import java.util.HashMap;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.takehome.Exceptions.InValidQuantityException;
import com.capgemini.takehome.Exceptions.ProductCodeNotFoundException;
import com.capgemini.takehome.bean.Product;
import com.capgemini.takehome.util.CollectionUtil;

import com.cg.takehome.services.IProductService;
import com.cg.takehome.services.ProductService;



public class JUnit {
	private static IProductService prodServiceTest;
	//before class annotation is used for setting the variables which is used in whole class
	@BeforeClass
	public static void setUpTestEnv() {
		 prodServiceTest=new ProductService();
	}
	// it is used to define those things which can be used in each of methods
	@Before
	public void setUpTestData() {
	
		Product pro1= new Product("IPhone","Electronics","SmartPhone",1008,35000.0f);
		Product pro2=new Product("Telescope","Toys","PlayItem",1009,5000.0f);
		CollectionUtil.products.put(1008,pro1);	
		CollectionUtil.products.put(1009, pro2);
		
	}
	//Test annotation is used for testing methods
	@Test(expected=ProductCodeNotFoundException.class)
	public void testGetDetailsForInvalidProductCode() throws ProductCodeNotFoundException{
		prodServiceTest.validateProductCode(1005);
	
	}
	
	@Test
	public void testGetDetailsForValidProductCode() {

		Product actual=prodServiceTest.getProductDetails(1008);
		Assert.assertEquals(1008,actual.getProductCode());
		}
	@Test(expected=InValidQuantityException.class)
	public void testforInvalidQuntity() throws InValidQuantityException{
	
		prodServiceTest.validateProductQuantity(0);
	}
	@Test
	public void testforvalidProductQuantity()
	{
		boolean expected=true;
		boolean actual=prodServiceTest.validateProductQuantity(100);
		Assert.assertEquals(expected, actual);
	}
	@Test(expected=ProductCodeNotFoundException.class)
	public void testforInvalidproductCodegetDetails() throws ProductCodeNotFoundException{
		prodServiceTest.getProductDetails(1005).getProductCode();
	}
	@Test
	public void testforValidProductCodeGetDetails()
	{
	Product pro= new Product("LEDTV", "Electronics", "TV", 1005, 45000.0f);
	CollectionUtil.products.put(1005, pro);
		Product actual=CollectionUtil.products.get(1005);
		Assert.assertEquals(1005,actual.getProductCode());
			}
	@Test
	public void testforrightValidProductCategoryInsertDetails() {
		
		Product prod= new Product("LEDTV", "Electronics", "TV", 1006, 45000.0f);
		CollectionUtil.products.put(1006, prod);
		String expected=prod.getCategory();
			Product actual=CollectionUtil.products.get(1006);
			Assert.assertEquals(expected, actual.getCategory());
		
	}
	@Test
public void testforrightgetInsertDetails() {
		//Product p= new Produ
		Product prod= new Product("LEDTV", "Electronics", "TV", 1007, 45000.0f);
		CollectionUtil.products.put(1007, prod);
		
	}
	
	
	
	
	@After
	//after is used for clear those value which is not required after performing all the methods
	public void tearDownData() {
		CollectionUtil.products.clear();
	}
	@AfterClass
	//afterclass is used for releasing the external which are used in before class
	public static void tearDownEnv() {
		prodServiceTest=null;
	}
	
}
