package com.capgemini.takehome.bean;
//it is the bean class
public class Product {
	String productName;
	String category;
	String productDescription;
	int productCode;
	float productPrice;
	int  quantity;

	//below is constructor for getting input from user1.productcode and 2nd is  the quantity
	public Product(int productCode, int quantity) {
		super();
		this.productCode = productCode;
		this.quantity = quantity;
	}
	
	
	/*below 
	 * are 
	 * getters and 
	 * setters
	 */
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	
	

	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	
	//it is the tostring method for printing the constructor passed value in the form strings
	
	@Override
	public String toString() {
		return "Product [productName=" + productName + ", category=" + category + ", productDescription="
				+ productDescription + ", productCode=" + productCode + ", productPrice=" + productPrice + 
			 "]";
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getProductDescription() {
		return productDescription;
	}
	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}
	public int getProductCode() {
		return productCode;
	}
	public void setProductCode(int productCode) {
		this.productCode = productCode;
	}
	public float getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(float productPrice) {
		this.productPrice = productPrice;
	}
	public Product() {
		super();
		
	}
	// below constructor is used for pushing data in util 
	public Product(String productName, String category, String productDescription, int productCode,
			float productPrice) {
		super();
		this.productName = productName;
		this.category = category;
		this.productDescription = productDescription;
		this.productCode = productCode;
		this.productPrice = productPrice;
	}

}
