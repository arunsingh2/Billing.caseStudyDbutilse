package com.capgemini.takehome.ui;

import java.util.InputMismatchException;
import java.util.Scanner;

import com.capgemini.takehome.Exceptions.InValidQuantityException;
import com.capgemini.takehome.bean.Product;
import com.cg.takehome.services.ProductService;

public class Client {
	ProductService services= new ProductService();
	
	public void insertDetails()
	{
	Scanner sc= new Scanner(System.in);
	System.out.println("Enter product code");
	int prodCod=sc.nextInt();// getting product code as input from the client
	try {
	services.validateProductCode(prodCod);
	}
	catch(Exception e)
	{
		System.out.println("sorry product code is not valid !!!!!!!!!!!!!!!!!!!!!!");
	}
	System.out.println("Enter product quantity");
	int qunt=0;
	try {
		 qunt = sc.nextInt();
	} catch (InputMismatchException e) {
		
		System.out.println(e.getMessage());
	}
	catch(InValidQuantityException e)
	{System.out.println(e.getMessage());
	}// getting input of quantity of particular code from user
	
	services.validateProductQuantity(qunt);
	Product prod= new Product(prodCod, qunt);
	
	//System.out.println(services.getProductDetails(prodCod));

		
			try {
				System.out.println("Product Name:"+services.getProductDetails(prodCod).getProductName());
				System.out.println("Product Category:"+services.getProductDetails(prod.getProductCode()).getCategory());
				System.out.println("Product Description:"+services.getProductDetails(prod.getProductCode()).getProductDescription());
				System.out.println("Product Price(Rs):"+services.getProductDetails(prod.getProductCode()).getProductPrice());
				System.out.println(qunt);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
	}
	public static void main(String[] args) {
		Client client= new Client();
		int flag=0;
		while(flag==0) {
		System.out.println("Enter 1 for getting order,enter 2 for exit");
		Scanner sc= new Scanner(System.in);
		int choice=sc.nextInt();
		switch(choice)
		{
		case 1:
		client.insertDetails();
		//System.out.println("Enter 1 for getting order,enter 2 for exit");
	    break;
		case 2:
			System.exit(choice);
			defalult:
			System.out.println("transaction is complete");
		
	
	}}

}}
